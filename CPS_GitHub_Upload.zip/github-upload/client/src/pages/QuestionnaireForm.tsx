import { useState } from 'react';
import { useParams, useLocation } from 'wouter';
import { useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
// Toast notifications will be added later
import { Loader2 } from 'lucide-react';

// Country configurations
const COUNTRIES = {
  jordan: {
    name: 'الأردن',
    nameEn: 'Jordan',
    locationLabel: 'المدينة التي تقيم فيها حاليًا',
    locations: [
      'عمان', 'إربد', 'الزرقاء', 'المفرق', 'جرش', 'عجلون',
      'مأدبا', 'البلقاء', 'العقبة', 'الطفيلة', 'الكرك', 'معان'
    ]
  },
  uae: {
    name: 'الإمارات العربية المتحدة',
    nameEn: 'UAE',
    locationLabel: 'الإمارة التي تقيم فيها حاليًا',
    locations: [
      'أبوظبي', 'دبي', 'الشارقة', 'رأس الخيمة',
      'عجمان', 'أم القيوين', 'الفجيرة'
    ]
  },
  ksa: {
    name: 'المملكة العربية السعودية',
    nameEn: 'KSA',
    locationLabel: 'المنطقة الإدارية التي تقيم فيها حاليًا',
    locations: [
      'الرياض', 'مكة المكرمة', 'المدينة المنورة', 'القصيم',
      'الشرقية', 'عسير', 'تبوك', 'حائل',
      'الحدود الشمالية', 'جازان', 'نجران', 'الباحة', 'الجوف'
    ]
  },
  algeria: {
    name: 'الجزائر',
    nameEn: 'Algeria',
    locationLabel: 'الولاية التي تقيم فيها حاليًا',
    locations: [
      'أدرار', 'الشلف', 'الأغواط', 'أم البواقي', 'باتنة', 'بجاية',
      'بسكرة', 'بشار', 'البليدة', 'البويرة', 'تمنراست', 'تبسة',
      'تلمسان', 'تيارت', 'تيزي وزو', 'الجزائر العاصمة', 'الجلفة', 'جيجل',
      'سطيف', 'سعيدة', 'سكيكدة', 'سيدي بلعباس', 'عنابة', 'قالمة',
      'قسنطينة', 'المدية', 'مستغانم', 'المسيلة', 'معسكر', 'ورقلة',
      'وهران', 'البيض', 'إليزي', 'برج بوعريريج', 'بومرداس', 'الطارف',
      'تندوف', 'تيسمسيلت', 'الوادي', 'خنشلة', 'سوق أهراس', 'تيبازة',
      'ميلة', 'عين الدفلى', 'النعامة', 'عين تموشنت', 'غرداية', 'غليزان',
      'تيميمون', 'برج باجي مختار', 'أولاد جلال', 'بني عباس', 'عين صالح',
      'عين قزام', 'تقرت', 'جانت', 'المغير', 'المنيعة'
    ]
  }
};

const LIKERT_STATEMENTS = [
  'التطبيقات التشخيصية المدعومة بالذكاء الاصطناعي تعزز بشكل كبير قدرة الصيادلة على اكتشاف المشكلات المحددة للحالات',
  'الأجهزة القابلة للارتداء وتطبيقات الصحة المحمولة تسهّل تطوير خطط علاج دوائي مخصصة يقودها الصيدلي',
  'المخاوف المتعلقة بخصوصية البيانات وأمن المعلومات تشكل حواجز جوهرية أمام التبني الفعال لأدوات الصيدلة الرقمية',
  'الاستشارات عن بعد تمكّن الصيادلة من توسيع نطاق خدمات الصيدلة المعرفية',
  'دمج تقنيات الصحة الرقمية أمر حاسم لتطوير نماذج خدمات الصيدلة المعرفية',
  'برامج محو الأمية الرقمية القوية ضرورية لضمان وصول المرضى بشكل عادل إلى الابتكارات',
  'الأدوات المدعومة بالذكاء الاصطناعي تعزز تقديم خدمات الصيدلة المعرفية في رعاية ما قبل وأثناء الحمل',
  'منصات الصحة النفسية الرقمية توفر دعمًا قيّمًا للمرضى الذين يعانون من القلق والاكتئاب',
  'استخدام الأدوات الرقمية المدمجة يحسن الكفاءة التشغيلية ويعزز رضا المرضى',
  'تنفيذ بروتوكولات بيانات مصنفة حسب النوع الاجتماعي أمر حيوي للحد من تحيز الذكاء الاصطناعي',
  'خدمات الصيدلة عن بعد توسع إمكانية الوصول، خاصة في المناطق النائية',
  'أنظمة الوصفات الإلكترونية تحسن سلامة خدمات الصيدلة من خلال تقليل الأخطاء الدوائية',
  'الأنظمة الصيدلانية الذاتية تبسط سير عمل خدمات الصيدلة المعرفية',
  'المنصات الرقمية المصممة خصيصًا لصحة المرأة توسع بشكل كبير نطاق وجودة الخدمات'
];

export default function QuestionnaireForm() {
  const params = useParams();
  const [, setLocation] = useLocation();
  // Toast functionality
  const country = params.country as keyof typeof COUNTRIES;
  const countryConfig = COUNTRIES[country];

  const [formData, setFormData] = useState({
    city: '',
    environment: '',
    pharmacyType: '',
    position: '',
    gender: '',
    yearsOfPractice: '',
    qualification: '',
    confidenceLevel: '',
    receivedTraining: '',
    knowledgeLevel: '',
    likertResponses: Array(14).fill(''),
    providesDigitalServices: '',
    digitalConsultationPercentage: '',
    digitalTools: [] as string[],
    pharmacyReadiness: '',
    barriers: [] as string[],
    trainingNeeds: [] as string[],
    additionalSupport: '',
    digitalCollaborations: ''
  });

  const submitMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const response = await fetch('/api/responses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...data, country }),
      });
      if (!response.ok) throw new Error('Failed to submit');
      return response.json();
    },
    onSuccess: () => {
      alert('شكراً لك! تم إرسال إجاباتك بنجاح');
      setLocation('/thank-you');
    },
    onError: () => {
      alert('حدث خطأ أثناء الإرسال. يرجى المحاولة مرة أخرى');
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitMutation.mutate(formData);
  };

  if (!countryConfig) {
    return <div className="container mx-auto p-4">Invalid country</div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white" dir="rtl">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-blue-900 mb-2">
            استبيان: النهوض بالتكامل الصحي الرقمي في صحة المرأة
          </h1>
          <h2 className="text-2xl md:text-3xl font-semibold text-blue-800 mb-4">
            خدمات الصيدلة
          </h2>
          <div className="inline-block bg-blue-100 px-4 py-2 rounded-lg">
            <p className="text-lg font-medium text-blue-900">{countryConfig.name}</p>
          </div>
        </div>

        {/* Introduction */}
        <Card className="mb-6 bg-blue-50 border-blue-200">
          <CardContent className="pt-6">
            <p className="font-semibold mb-2">عزيزي/عزيزتي الصيدلي/الصيدلانية،</p>
            <p className="mb-2">ندعوك للمشاركة في استبيان بحثي يهدف إلى استكشاف دمج تقنيات الصحة الرقمية في خدمات صحة المرأة ضمن الممارسة الصيدلانية المجتمعية.</p>
            <ul className="list-disc list-inside space-y-1 text-sm">
              <li>المشاركة طوعية ومجهولة الهوية</li>
              <li>الوقت المقدر: 10 دقائق</li>
              <li className="text-red-600 font-semibold">* يشير إلى الإلزامية إجابة السؤال</li>
            </ul>
          </CardContent>
        </Card>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Section 1 */}
          <Card className="border-blue-900 border-t-4">
            <CardHeader className="bg-blue-900 text-white">
              <CardTitle>القسم الأول: الخلفية الديموغرافية والمهنية</CardTitle>
            </CardHeader>
            <CardContent className="pt-6 space-y-6">
              {/* City/Location */}
              <div>
                <Label className="text-base font-semibold mb-3 block">
                  1. {countryConfig.locationLabel} <span className="text-red-600">*</span>
                </Label>
                <RadioGroup
                  value={formData.city}
                  onValueChange={(value) => setFormData({ ...formData, city: value })}
                  className="grid grid-cols-2 md:grid-cols-3 gap-3"
                  required
                >
                  {countryConfig.locations.map((location, idx) => (
                    <div key={idx} className="flex items-center space-x-2 space-x-reverse">
                      <RadioGroupItem value={location} id={`city-${idx}`} />
                      <Label htmlFor={`city-${idx}`} className="cursor-pointer">
                        {idx + 1}. {location}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>

              {/* Environment */}
              <div>
                <Label className="text-base font-semibold mb-3 block">
                  2. البيئة الصيدلانية: <span className="text-red-600">*</span>
                </Label>
                <RadioGroup
                  value={formData.environment}
                  onValueChange={(value) => setFormData({ ...formData, environment: value })}
                  className="grid grid-cols-2 md:grid-cols-4 gap-3"
                  required
                >
                  {['حضرية', 'ريفية', 'ضاحية', 'مخيم لاجئين'].map((env, idx) => (
                    <div key={idx} className="flex items-center space-x-2 space-x-reverse">
                      <RadioGroupItem value={env} id={`env-${idx}`} />
                      <Label htmlFor={`env-${idx}`} className="cursor-pointer">
                        {idx + 1}. {env}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>

              {/* Pharmacy Type */}
              <div>
                <Label className="text-base font-semibold mb-3 block">
                  3. نوع الصيدلية: <span className="text-red-600">*</span>
                </Label>
                <RadioGroup
                  value={formData.pharmacyType}
                  onValueChange={(value) => setFormData({ ...formData, pharmacyType: value })}
                  className="grid grid-cols-1 md:grid-cols-2 gap-3"
                  required
                >
                  {['صيدلية مستقلة', 'سلسلة صيدليات', 'عيادة خارجية (مستشفى)', 'أخرى'].map((type, idx) => (
                    <div key={idx} className="flex items-center space-x-2 space-x-reverse">
                      <RadioGroupItem value={type} id={`pharm-${idx}`} />
                      <Label htmlFor={`pharm-${idx}`} className="cursor-pointer">
                        {idx + 1}. {type}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>

              {/* Position */}
              <div>
                <Label className="text-base font-semibold mb-3 block">
                  4. المنصب/الدور: <span className="text-red-600">*</span>
                </Label>
                <RadioGroup
                  value={formData.position}
                  onValueChange={(value) => setFormData({ ...formData, position: value })}
                  className="grid grid-cols-1 md:grid-cols-3 gap-3"
                  required
                >
                  {['صيدلي موظف', 'مدير/مالك صيدلية', 'أخرى'].map((pos, idx) => (
                    <div key={idx} className="flex items-center space-x-2 space-x-reverse">
                      <RadioGroupItem value={pos} id={`pos-${idx}`} />
                      <Label htmlFor={`pos-${idx}`} className="cursor-pointer">
                        {idx + 1}. {pos}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>

              {/* Gender */}
              <div>
                <Label className="text-base font-semibold mb-3 block">
                  5. الجنس: <span className="text-red-600">*</span>
                </Label>
                <RadioGroup
                  value={formData.gender}
                  onValueChange={(value) => setFormData({ ...formData, gender: value })}
                  className="grid grid-cols-2 gap-3"
                  required
                >
                  {['ذكر', 'أنثى'].map((gender, idx) => (
                    <div key={idx} className="flex items-center space-x-2 space-x-reverse">
                      <RadioGroupItem value={gender} id={`gender-${idx}`} />
                      <Label htmlFor={`gender-${idx}`} className="cursor-pointer">
                        {idx + 1}. {gender}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>

              {/* Years of Practice */}
              <div>
                <Label className="text-base font-semibold mb-3 block">
                  6. سنوات الممارسة: <span className="text-red-600">*</span>
                </Label>
                <RadioGroup
                  value={formData.yearsOfPractice}
                  onValueChange={(value) => setFormData({ ...formData, yearsOfPractice: value })}
                  className="grid grid-cols-2 md:grid-cols-4 gap-3"
                  required
                >
                  {['0-5 سنوات', '6-10 سنوات', '11-15 سنة', 'أكثر من 15 سنة'].map((years, idx) => (
                    <div key={idx} className="flex items-center space-x-2 space-x-reverse">
                      <RadioGroupItem value={years} id={`years-${idx}`} />
                      <Label htmlFor={`years-${idx}`} className="cursor-pointer">
                        {idx + 1}. {years}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>

              {/* Qualification */}
              <div>
                <Label className="text-base font-semibold mb-3 block">
                  7. أعلى مؤهل علمي: <span className="text-red-600">*</span>
                </Label>
                <RadioGroup
                  value={formData.qualification}
                  onValueChange={(value) => setFormData({ ...formData, qualification: value })}
                  className="grid grid-cols-1 md:grid-cols-2 gap-3"
                  required
                >
                  {['بكالوريوس صيدلة', 'دكتور صيدلة (PharmD)', 'ماجستير صيدلة سريرية', 'ماجستير علوم صيدلانية', 'دكتوراه', 'أخرى'].map((qual, idx) => (
                    <div key={idx} className="flex items-center space-x-2 space-x-reverse">
                      <RadioGroupItem value={qual} id={`qual-${idx}`} />
                      <Label htmlFor={`qual-${idx}`} className="cursor-pointer">
                        {idx + 1}. {qual}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>
            </CardContent>
          </Card>

          {/* Section 2 */}
          <Card className="border-green-700 border-t-4">
            <CardHeader className="bg-green-700 text-white">
              <CardTitle>القسم الثاني: المعرفة والمواقف والممارسات المتعلقة بالصحة الرقمية</CardTitle>
            </CardHeader>
            <CardContent className="pt-6 space-y-6">
              {/* Confidence Level */}
              <div>
                <Label className="text-base font-semibold mb-3 block">
                  8. مدى ثقتك في استخدام الأدوات الرقمية لتقديم خدمات صحة المرأة: <span className="text-red-600">*</span>
                </Label>
                <RadioGroup
                  value={formData.confidenceLevel}
                  onValueChange={(value) => setFormData({ ...formData, confidenceLevel: value })}
                  className="grid grid-cols-1 md:grid-cols-2 gap-3"
                  required
                >
                  {['غير واثق', 'واثق قليلاً', 'واثق إلى حد ما', 'واثق جدًا', 'واثق للغاية'].map((conf, idx) => (
                    <div key={idx} className="flex items-center space-x-2 space-x-reverse">
                      <RadioGroupItem value={conf} id={`conf-${idx}`} />
                      <Label htmlFor={`conf-${idx}`} className="cursor-pointer">
                        {idx + 1}. {conf}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>

              {/* Training */}
              <div>
                <Label className="text-base font-semibold mb-3 block">
                  9. هل تلقيت تدريبًا رسميًا في الصحة الرقمية أو الصيدلة عن بعد؟ <span className="text-red-600">*</span>
                </Label>
                <RadioGroup
                  value={formData.receivedTraining}
                  onValueChange={(value) => setFormData({ ...formData, receivedTraining: value })}
                  className="grid grid-cols-1 md:grid-cols-3 gap-3"
                  required
                >
                  {['نعم', 'لا', 'أخرى'].map((train, idx) => (
                    <div key={idx} className="flex items-center space-x-2 space-x-reverse">
                      <RadioGroupItem value={train} id={`train-${idx}`} />
                      <Label htmlFor={`train-${idx}`} className="cursor-pointer">
                        {idx + 1}. {train}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>

              {/* Knowledge Level */}
              <div>
                <Label className="text-base font-semibold mb-3 block">
                  10. كيف تقيم مستوى معرفتك بالصحة الرقمية: <span className="text-red-600">*</span>
                </Label>
                <RadioGroup
                  value={formData.knowledgeLevel}
                  onValueChange={(value) => setFormData({ ...formData, knowledgeLevel: value })}
                  className="grid grid-cols-2 md:grid-cols-4 gap-3"
                  required
                >
                  {['منخفض', 'متوسط', 'فوق المتوسط', 'عالٍ'].map((know, idx) => (
                    <div key={idx} className="flex items-center space-x-2 space-x-reverse">
                      <RadioGroupItem value={know} id={`know-${idx}`} />
                      <Label htmlFor={`know-${idx}`} className="cursor-pointer">
                        {idx + 1}. {know}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>
            </CardContent>
          </Card>

          {/* Section 3 - Likert Scale */}
          <Card className="border-purple-700 border-t-4">
            <CardHeader className="bg-purple-700 text-white">
              <CardTitle>القسم الثالث: دمج الصحة الرقمية - المواقف والحواجز</CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <p className="text-sm text-gray-600 italic mb-4">
                مقياس الإجابة: 1 = أعارض بشدة | 2 = أعارض | 3 = محايد | 4 = أوافق | 5 = أوافق بشدة | 6 = لا ينطبق
              </p>
              <div className="space-y-6">
                {LIKERT_STATEMENTS.map((statement, idx) => (
                  <div key={idx} className="p-4 bg-gray-50 rounded-lg">
                    <p className="font-medium mb-3">
                      {String.fromCharCode(1571 + idx)}) {statement}
                    </p>
                    <RadioGroup
                      value={formData.likertResponses[idx]}
                      onValueChange={(value) => {
                        const newResponses = [...formData.likertResponses];
                        newResponses[idx] = value;
                        setFormData({ ...formData, likertResponses: newResponses });
                      }}
                      className="grid grid-cols-2 md:grid-cols-3 gap-2"
                      required
                    >
                      {['أعارض بشدة', 'أعارض', 'محايد', 'أوافق', 'أوافق بشدة', 'لا ينطبق'].map((option, optIdx) => (
                        <div key={optIdx} className="flex items-center space-x-2 space-x-reverse">
                          <RadioGroupItem value={option} id={`likert-${idx}-${optIdx}`} />
                          <Label htmlFor={`likert-${idx}-${optIdx}`} className="cursor-pointer text-sm">
                            {optIdx + 1}. {option}
                          </Label>
                        </div>
                      ))}
                    </RadioGroup>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Section 4 - Digital Service Delivery */}
          <Card className="border-orange-600 border-t-4">
            <CardHeader className="bg-orange-600 text-white">
              <CardTitle>القسم الرابع: تقديم خدمات الصيدلة المعرفية الرقمية</CardTitle>
            </CardHeader>
            <CardContent className="pt-6 space-y-6">
              {/* Q12 */}
              <div>
                <Label className="text-base font-semibold mb-3 block">
                  12. هل تقدم خدمات صيدلة سريرية لصحة المرأة عبر قنوات رقمية؟ <span className="text-red-600">*</span>
                </Label>
                <RadioGroup
                  value={formData.providesDigitalServices}
                  onValueChange={(value) => setFormData({ ...formData, providesDigitalServices: value })}
                  className="grid grid-cols-2 gap-3"
                  required
                >
                  {['نعم', 'لا'].map((opt, idx) => (
                    <div key={idx} className="flex items-center space-x-2 space-x-reverse">
                      <RadioGroupItem value={opt} id={`q12-${idx}`} />
                      <Label htmlFor={`q12-${idx}`} className="cursor-pointer">
                        {idx + 1}. {opt}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>

              {/* Q13 */}
              <div>
                <Label className="text-base font-semibold mb-3 block">
                  13. نسبة الاستشارات التي تستخدم الأدوات الرقمية: <span className="text-red-600">*</span>
                </Label>
                <RadioGroup
                  value={formData.digitalConsultationPercentage}
                  onValueChange={(value) => setFormData({ ...formData, digitalConsultationPercentage: value })}
                  className="grid grid-cols-2 md:grid-cols-3 gap-3"
                  required
                >
                  {['0-20%', '21-40%', '41-60%', '61-80%', '81-100%'].map((opt, idx) => (
                    <div key={idx} className="flex items-center space-x-2 space-x-reverse">
                      <RadioGroupItem value={opt} id={`q13-${idx}`} />
                      <Label htmlFor={`q13-${idx}`} className="cursor-pointer">
                        {idx + 1}. {opt}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>

              {/* Q14 */}
              <div>
                <Label className="text-base font-semibold mb-3 block">
                  14. الأدوات/المنصات الرقمية المستخدمة: (اختر كل ما ينطبق) <span className="text-red-600">*</span>
                </Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {[
                    'منصات الاستشارات/المكالمات المرئية',
                    'تطبيقات الصحة المحمولة',
                    'السجلات الصحية الإلكترونية',
                    'تطبيقات التذكير/المتابعة الدوائية',
                    'أدوات دعم القرار المدعومة بالذكاء الاصطناعي',
                    'منصات الصحة النفسية الرقمية',
                    'منصات التواصل الاجتماعي',
                    'أخرى'
                  ].map((tool, idx) => (
                    <div key={idx} className="flex items-center space-x-2 space-x-reverse">
                      <Checkbox
                        id={`tool-${idx}`}
                        checked={formData.digitalTools.includes(tool)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setFormData({ ...formData, digitalTools: [...formData.digitalTools, tool] });
                          } else {
                            setFormData({ ...formData, digitalTools: formData.digitalTools.filter(t => t !== tool) });
                          }
                        }}
                      />
                      <Label htmlFor={`tool-${idx}`} className="cursor-pointer">
                        {idx + 1}. {tool}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Q15 */}
              <div>
                <Label className="text-base font-semibold mb-3 block">
                  15. كيف تصف جاهزية صيدليتك لتنفيذ ابتكارات الصحة الرقمية؟ <span className="text-red-600">*</span>
                </Label>
                <RadioGroup
                  value={formData.pharmacyReadiness}
                  onValueChange={(value) => setFormData({ ...formData, pharmacyReadiness: value })}
                  className="grid grid-cols-2 md:grid-cols-3 gap-3"
                  required
                >
                  {['غير جاهز', 'جاهز قليلاً', 'جاهز إلى حد ما', 'جاهز جدًا', 'جاهز بالكامل'].map((opt, idx) => (
                    <div key={idx} className="flex items-center space-x-2 space-x-reverse">
                      <RadioGroupItem value={opt} id={`q15-${idx}`} />
                      <Label htmlFor={`q15-${idx}`} className="cursor-pointer">
                        {idx + 1}. {opt}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>
            </CardContent>
          </Card>

          {/* Section 5 - Barriers & Training */}
          <Card className="border-red-700 border-t-4">
            <CardHeader className="bg-red-700 text-white">
              <CardTitle>القسم الخامس: الحواجز واحتياجات التدريب</CardTitle>
            </CardHeader>
            <CardContent className="pt-6 space-y-6">
              {/* Q16 */}
              <div>
                <Label className="text-base font-semibold mb-3 block">
                  16. الحواجز الرئيسية أمام دمج أدوات الصحة الرقمية: (اختر كل ما ينطبق) <span className="text-red-600">*</span>
                </Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {[
                    'قيود عبء العمل ونقص الكوادر',
                    'المهارات والتدريب وسهولة الاستخدام',
                    'التكنولوجيا والبنية التحتية والتكامل',
                    'الحوكمة والخصوصية والمسؤولية القانونية',
                    'انخفاض طلب المرضى',
                    'التمويل والتعويض والعائد على الاستثمار',
                    'القيادة والثقافة والدعم المؤسسي',
                    'وصول المرضى ومحو الأمية الرقمية',
                    'الأدلة والنتائج القابلة للقياس',
                    'أخرى'
                  ].map((barrier, idx) => (
                    <div key={idx} className="flex items-center space-x-2 space-x-reverse">
                      <Checkbox
                        id={`barrier-${idx}`}
                        checked={formData.barriers.includes(barrier)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setFormData({ ...formData, barriers: [...formData.barriers, barrier] });
                          } else {
                            setFormData({ ...formData, barriers: formData.barriers.filter(b => b !== barrier) });
                          }
                        }}
                      />
                      <Label htmlFor={`barrier-${idx}`} className="cursor-pointer">
                        {idx + 1}. {barrier}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Q17 */}
              <div>
                <Label className="text-base font-semibold mb-3 block">
                  17. التدريب أو الدعم المطلوب: (اختر كل ما ينطبق) <span className="text-red-600">*</span>
                </Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {[
                    'المهارات الرقمية الأساسية',
                    'التنقل في أدوات الذكاء الاصطناعي',
                    'التطبيقات السريرية في صحة المرأة',
                    'حماية البيانات والخصوصية والموافقة',
                    'دمج سير العمل وقابلية التشغيل البيني',
                    'تثقيف المرضى والمشاركة الرقمية',
                    'التعاون بين المهنيين',
                    'المراقبة والتقييم',
                    'الدعم العملي',
                    'أخرى'
                  ].map((training, idx) => (
                    <div key={idx} className="flex items-center space-x-2 space-x-reverse">
                      <Checkbox
                        id={`training-${idx}`}
                        checked={formData.trainingNeeds.includes(training)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setFormData({ ...formData, trainingNeeds: [...formData.trainingNeeds, training] });
                          } else {
                            setFormData({ ...formData, trainingNeeds: formData.trainingNeeds.filter(t => t !== training) });
                          }
                        }}
                      />
                      <Label htmlFor={`training-${idx}`} className="cursor-pointer">
                        {idx + 1}. {training}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Q18 */}
              <div>
                <Label className="text-base font-semibold mb-3 block">
                  18. الدعم الإضافي المطلوب لتحسين تقديم خدمات الصحة الرقمية:
                </Label>
                <Textarea
                  value={formData.additionalSupport}
                  onChange={(e) => setFormData({ ...formData, additionalSupport: e.target.value })}
                  rows={4}
                  className="w-full"
                  placeholder="اكتب إجابتك هنا..."
                />
              </div>

              {/* Q19 */}
              <div>
                <Label className="text-base font-semibold mb-3 block">
                  19. كيف يمكن للتعاونات الرقمية تحسين خدمات الصيدلة المعرفية لصحة المرأة؟
                </Label>
                <Textarea
                  value={formData.digitalCollaborations}
                  onChange={(e) => setFormData({ ...formData, digitalCollaborations: e.target.value })}
                  rows={4}
                  className="w-full"
                  placeholder="اكتب إجابتك هنا..."
                />
              </div>
            </CardContent>
          </Card>

          {/* Submit Button */}
          <div className="flex justify-center pt-6">
            <Button
              type="submit"
              size="lg"
              className="bg-blue-900 hover:bg-blue-800 text-white px-12 py-6 text-lg"
              disabled={submitMutation.isPending}
            >
              {submitMutation.isPending ? (
                <>
                  <Loader2 className="ml-2 h-5 w-5 animate-spin" />
                  جاري الإرسال...
                </>
              ) : (
                'إرسال الإجابات'
              )}
            </Button>
          </div>
        </form>

        {/* Footer */}
        <div className="mt-8 text-center bg-blue-50 p-6 rounded-lg">
          <p className="font-semibold text-lg mb-2">شكرًا لك على وقتك ومشاركتك القيمة!</p>
          <p className="text-sm text-gray-700">
            تم إعداد هذا الاستبيان لأغراض البحث العلمي، وجميع المعلومات المقدمة ستبقى سرية ومجهولة الهوية.
          </p>
          
          <p className="text-xs text-gray-500 mt-1">© 2025 Cognitive Pharmacy Models Across MENA Region</p>
        </div>
      </div>
    </div>
  );
}

