import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'wouter';
import { Globe, FileText, Database, Shield } from 'lucide-react';

const COUNTRIES = [
  { id: 'jordan', name: 'الأردن', nameEn: 'Jordan', flag: '🇯🇴' },
  { id: 'uae', name: 'الإمارات العربية المتحدة', nameEn: 'UAE', flag: '🇦🇪' },
  { id: 'ksa', name: 'المملكة العربية السعودية', nameEn: 'Saudi Arabia', flag: '🇸🇦' },
  { id: 'algeria', name: 'الجزائر', nameEn: 'Algeria', flag: '🇩🇿' }
];

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-6">
          <div className="text-center">
            <h1 className="text-2xl md:text-3xl font-bold text-blue-900">
              Cognitive Pharmacy Models Across MENA Region
            </h1>
            <p className="text-sm text-gray-600 mt-1">Community Pharmacy Services Research</p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12 max-w-6xl">
        {/* Title Section */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4" dir="rtl">
            استبيان: النهوض بالتكامل الصحي الرقمي في صحة المرأة
          </h2>
          <h3 className="text-2xl md:text-3xl font-semibold text-blue-800 mb-6" dir="rtl">
            خدمات الصيدلة المعرفية
          </h3>
          <p className="text-lg text-gray-700 max-w-3xl mx-auto">
            Advancing Digital Health Integration in Women's Health: Cognitive Pharmacy Services
          </p>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <Card className="text-center">
            <CardContent className="pt-6">
              <Globe className="h-12 w-12 text-blue-600 mx-auto mb-3" />
              <h4 className="font-semibold mb-2">Multi-Country</h4>
              <p className="text-sm text-gray-600">4 Arab Countries</p>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="pt-6">
              <FileText className="h-12 w-12 text-green-600 mx-auto mb-3" />
              <h4 className="font-semibold mb-2">Comprehensive</h4>
              <p className="text-sm text-gray-600">5 Sections Survey</p>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="pt-6">
              <Database className="h-12 w-12 text-purple-600 mx-auto mb-3" />
              <h4 className="font-semibold mb-2">Auto-Sync</h4>
              <p className="text-sm text-gray-600">Google Sheets Integration</p>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="pt-6">
              <Shield className="h-12 w-12 text-red-600 mx-auto mb-3" />
              <h4 className="font-semibold mb-2">Anonymous</h4>
              <p className="text-sm text-gray-600">Confidential & Secure</p>
            </CardContent>
          </Card>
        </div>

        {/* Country Selection */}
        <Card className="mb-8">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
            <CardTitle className="text-center text-2xl">
              <span dir="rtl">اختر دولتك / Select Your Country</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-8 pb-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
              {COUNTRIES.map((country) => (
                <Link key={country.id} href={`/form/${country.id}`}>
                  <Button
                    variant="outline"
                    size="lg"
                    className="w-full h-auto py-6 text-lg hover:bg-blue-50 hover:border-blue-500 transition-all"
                  >
                    <div className="flex items-center justify-between w-full">
                      <span className="text-4xl">{country.flag}</span>
                      <div className="flex-1 text-center">
                        <div className="font-bold text-xl" dir="rtl">{country.name}</div>
                        <div className="text-sm text-gray-600">{country.nameEn}</div>
                      </div>
                      <div className="text-blue-600">→</div>
                    </div>
                  </Button>
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Information */}
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="pt-6" dir="rtl">
            <h3 className="font-bold text-lg mb-4 text-blue-900">معلومات مهمة:</h3>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start">
                <span className="text-blue-600 ml-2 mr-2">•</span>
                <span>المشاركة طوعية ومجهولة الهوية تماماً</span>
              </li>
              <li className="flex items-start">
                <span className="text-blue-600 ml-2 mr-2">•</span>
                <span>الوقت المقدر لإكمال الاستبيان: 10-15 دقيقة</span>
              </li>
              <li className="flex items-start">
                <span className="text-blue-600 ml-2 mr-2">•</span>
                <span>جميع البيانات سيتم استخدامها لأغراض البحث العلمي فقط</span>
              </li>
              <li className="flex items-start">
                <span className="text-blue-600 ml-2 mr-2">•</span>
                <span>يتم حفظ الإجابات تلقائياً في قاعدة بيانات آمنة ومشفرة</span>
              </li>
              <li className="flex items-start">
                <span className="text-blue-600 ml-2 mr-2">•</span>
                <span>يمكنك إكمال الاستبيان من الهاتف المحمول أو الحاسوب</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-12 text-sm text-gray-600">
          
          <p className="mt-2">© 2025 Cognitive Pharmacy Models Across MENA Region</p>
        </div>
      </div>
    </div>
  );
}

