import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { CheckCircle } from 'lucide-react';
import { Link } from 'wouter';

export default function ThankYou() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white flex items-center justify-center p-4" dir="rtl">
      <Card className="max-w-2xl w-full">
        <CardContent className="pt-12 pb-8 text-center">
          <div className="flex justify-center mb-6">
            <CheckCircle className="h-24 w-24 text-green-600" />
          </div>
          
          <h1 className="text-3xl md:text-4xl font-bold text-green-900 mb-4">
            شكراً لك على مشاركتك!
          </h1>
          
          <p className="text-lg text-gray-700 mb-6">
            تم إرسال إجاباتك بنجاح. نقدر وقتك ومساهمتك القيمة في هذا البحث.
          </p>
          
          <div className="bg-blue-50 p-6 rounded-lg mb-8">
            <p className="text-gray-800 mb-2">
              <strong>ملاحظة:</strong> جميع المعلومات المقدمة ستبقى سرية ومجهولة الهوية.
            </p>
            <p className="text-gray-700">
              سيتم استخدام البيانات لأغراض البحث العلمي فقط لتحسين خدمات الصيدلة الرقمية في صحة المرأة.
            </p>
          </div>
          
          <div className="space-y-4">
            <p className="text-sm text-gray-600">
              إذا كان لديك أي استفسارات أو ترغب في معرفة المزيد عن هذا البحث، يرجى التواصل معنا.
            </p>
            
            <div className="text-xs text-gray-600 mt-6">
              
              <p className="text-gray-500 mt-2">© 2025 Cognitive Pharmacy Models Across MENA Region</p>
            </div>
          </div>
          
          <div className="mt-8">
            <Link href="/">
              <Button variant="outline" size="lg">
                العودة إلى الصفحة الرئيسية
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

