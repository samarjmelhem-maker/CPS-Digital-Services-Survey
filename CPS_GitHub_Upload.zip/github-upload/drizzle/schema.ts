import { mysqlEnum, mysqlTable, text, timestamp, varchar, int, json, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: varchar("id", { length: 64 }).primaryKey(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Questionnaire responses table
 * Stores all form submissions with country-specific data
 */
export const responses = mysqlTable("responses", {
  id: int("id").primaryKey().autoincrement(),
  entryNumber: int("entryNumber").notNull(), // Sequential number per country
  country: mysqlEnum("country", ["jordan", "uae", "ksa", "algeria"]).notNull(),
  
  // Section 1: Demographics
  city: text("city"),
  environment: text("environment"),
  pharmacyType: text("pharmacyType"),
  position: text("position"),
  gender: text("gender"),
  yearsOfPractice: text("yearsOfPractice"),
  qualification: text("qualification"),
  
  // Section 2: Knowledge & Attitudes
  confidenceLevel: text("confidenceLevel"),
  receivedTraining: text("receivedTraining"),
  knowledgeLevel: text("knowledgeLevel"),
  
  // Section 3: Likert Scale Responses (14 items stored as JSON)
  likertResponses: json("likertResponses"),
  
  // Section 4: Digital Service Delivery
  providesDigitalServices: text("providesDigitalServices"),
  digitalConsultationPercentage: text("digitalConsultationPercentage"),
  digitalTools: json("digitalTools"), // Array of selected tools
  pharmacyReadiness: text("pharmacyReadiness"),
  
  // Section 5: Barriers & Training
  barriers: json("barriers"), // Array of selected barriers
  trainingNeeds: json("trainingNeeds"), // Array of selected training needs
  additionalSupport: text("additionalSupport"),
  digitalCollaborations: text("digitalCollaborations"),
  
  // Metadata
  submittedAt: timestamp("submittedAt").defaultNow(),
  ipAddress: varchar("ipAddress", { length: 45 }),
  userAgent: text("userAgent"),
  syncedToGoogleSheets: boolean("syncedToGoogleSheets").default(false),
  googleSheetsSyncedAt: timestamp("googleSheetsSyncedAt"),
});

export type Response = typeof responses.$inferSelect;
export type InsertResponse = typeof responses.$inferInsert;

/**
 * Google Sheets configuration table
 * Stores sheet IDs and sync status for each country
 */
export const googleSheetsConfig = mysqlTable("googleSheetsConfig", {
  id: int("id").primaryKey().autoincrement(),
  country: mysqlEnum("country", ["jordan", "uae", "ksa", "algeria"]).notNull().unique(),
  spreadsheetId: varchar("spreadsheetId", { length: 255 }),
  sheetName: varchar("sheetName", { length: 100 }),
  lastSyncedAt: timestamp("lastSyncedAt"),
  totalResponses: int("totalResponses").default(0),
  createdAt: timestamp("createdAt").defaultNow(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow(),
});

export type GoogleSheetsConfig = typeof googleSheetsConfig.$inferSelect;
export type InsertGoogleSheetsConfig = typeof googleSheetsConfig.$inferInsert;

