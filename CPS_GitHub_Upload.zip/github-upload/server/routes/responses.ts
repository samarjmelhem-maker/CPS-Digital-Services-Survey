import { Router } from 'express';
import { getDb } from '../db';
import { responses, googleSheetsConfig } from '../../drizzle/schema';
import { eq, and, sql } from 'drizzle-orm';
import { appendToGoogleSheet, syncResponseToGoogleSheets, syncAllUnsyncedResponses, exportToCSV } from '../services/googleSheets';

const router = Router();

// Submit a new response
router.post('/', async (req, res) => {
  try {
    const db = await getDb();
    if (!db) {
      return res.status(500).json({ error: 'Database not available' });
    }
    const {
      country,
      city,
      environment,
      pharmacyType,
      position,
      gender,
      yearsOfPractice,
      qualification,
      confidenceLevel,
      receivedTraining,
      knowledgeLevel,
      likertResponses,
      providesDigitalServices,
      digitalConsultationPercentage,
      digitalTools,
      pharmacyReadiness,
      barriers,
      trainingNeeds,
      additionalSupport,
      digitalCollaborations
    } = req.body;

    // Validate required fields
    if (!country || !city || !environment || !pharmacyType || !position || !gender || !yearsOfPractice || !qualification) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Get the next entry number for this country
    const result = await db
      .select({ maxEntry: sql<number>`COALESCE(MAX(${responses.entryNumber}), 0)` })
      .from(responses)
      .where(eq(responses.country, country));
    
    const entryNumber = (result[0]?.maxEntry || 0) + 1;

    // Get client IP and user agent
    const ipAddress = req.ip || req.socket.remoteAddress || '';
    const userAgent = req.get('user-agent') || '';

    // Insert the response
    const [newResponse] = await db.insert(responses).values({
      entryNumber,
      country,
      city,
      environment,
      pharmacyType,
      position,
      gender,
      yearsOfPractice,
      qualification,
      confidenceLevel,
      receivedTraining,
      knowledgeLevel,
      likertResponses: JSON.stringify(likertResponses),
      providesDigitalServices,
      digitalConsultationPercentage,
      digitalTools: JSON.stringify(digitalTools),
      pharmacyReadiness,
      barriers: JSON.stringify(barriers),
      trainingNeeds: JSON.stringify(trainingNeeds),
      additionalSupport,
      digitalCollaborations,
      ipAddress,
      userAgent,
      syncedToGoogleSheets: false
    });

    // Trigger Google Sheets sync (async, don't wait)
    const responseData = {
      city,
      environment,
      pharmacyType,
      position,
      gender,
      yearsOfPractice,
      qualification,
      confidenceLevel,
      receivedTraining,
      knowledgeLevel,
      likertResponses,
      providesDigitalServices,
      digitalConsultationPercentage,
      digitalTools,
      pharmacyReadiness,
      barriers,
      trainingNeeds,
      additionalSupport,
      digitalCollaborations,
      ipAddress
    };
    
    syncToGoogleSheets(responseData, country).catch(err => {
      console.error('Google Sheets sync error:', err);
    });

    res.json({ 
      success: true, 
      entryNumber,
      message: 'Response submitted successfully' 
    });
  } catch (error) {
    console.error('Error submitting response:', error);
    res.status(500).json({ error: 'Failed to submit response' });
  }
});

// Get all responses for a country (admin only)
router.get('/:country', async (req, res) => {
  try {
    const db = await getDb();
    if (!db) {
      return res.status(500).json({ error: 'Database not available' });
    }
    const { country } = req.params;
    
    const allResponses = await db
      .select()
      .from(responses)
      .where(eq(responses.country, country as any))
      .orderBy(responses.submittedAt);

    res.json(allResponses);
  } catch (error) {
    console.error('Error fetching responses:', error);
    res.status(500).json({ error: 'Failed to fetch responses' });
  }
});

// Get response statistics
router.get('/stats/:country', async (req, res) => {
  try {
    const db = await getDb();
    if (!db) {
      return res.status(500).json({ error: 'Database not available' });
    }
    const { country } = req.params;
    
    const stats = await db
      .select({
        total: sql<number>`COUNT(*)`,
        synced: sql<number>`SUM(CASE WHEN ${responses.syncedToGoogleSheets} = 1 THEN 1 ELSE 0 END)`
      })
      .from(responses)
      .where(eq(responses.country, country as any));

    res.json(stats[0] || { total: 0, synced: 0 });
  } catch (error) {
    console.error('Error fetching stats:', error);
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

// Sync a specific response to Google Sheets
async function syncToGoogleSheets(responseData: any, country: string) {
  await appendToGoogleSheet(country, responseData);
}

// Manual sync endpoint for all unsynced responses
router.post('/sync/:country', async (req, res) => {
  try {
    const db = await getDb();
    if (!db) {
      return res.status(500).json({ error: 'Database not available' });
    }
    const { country } = req.params;
    
    const unsyncedResponses = await db
      .select()
      .from(responses)
      .where(
        and(
          eq(responses.country, country as any),
          eq(responses.syncedToGoogleSheets, false)
        )
      );

    const syncedCount = await syncAllUnsyncedResponses(country);

    res.json({ 
      success: true, 
      synced: syncedCount,
      message: `Synced ${syncedCount} responses to Google Sheets` 
    });
  } catch (error) {
    console.error('Error syncing responses:', error);
    res.status(500).json({ error: 'Failed to sync responses' });
  }
});

export default router;



// Export responses as CSV
router.get('/export/:country/csv', async (req, res) => {
  try {
    const { country } = req.params;
    
    const csv = await exportToCSV(country);
    
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="${country}_responses.csv"`);
    res.send(csv);
  } catch (error) {
    console.error('Error exporting CSV:', error);
    res.status(500).json({ error: 'Failed to export CSV' });
  }
});

