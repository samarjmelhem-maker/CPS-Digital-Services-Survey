import { google } from 'googleapis';
import path from 'path';

const KEYFILE_PATH = path.join(process.cwd(), 'cps-survey-2025-ea0593a9edbc.json');

const SHEET_IDS = {
  jordan: '1d9WGIOupjMRrty7tU4ERDzpKjN5hOzmNfGLgz_xJrL0',
  uae: '1qe-wGiEwv2CVdrIIQYPWHVZYyRoLyYKJMSZdSUQE8RY',
  ksa: '1DZKBip9M_iXLArHZGwJvei1b6m7lOxbidF85YGbFjLA',
  algeria: '1cRK90FhDfMT4bFwhbz57F2lzVATAMM0r9KHz21hvEdw'
};

// Coding maps for categorical variables
const CODING_MAPS = {
  environment: { 'حضرية': 1, 'ريفية': 2, 'ضاحية': 3, 'مخيم لاجئين': 4 },
  pharmacyType: { 'صيدلية مستقلة': 1, 'سلسلة صيدليات': 2, 'عيادة خارجية (مستشفى)': 3, 'أخرى': 4 },
  position: { 'صيدلي موظف': 1, 'مدير/مالك صيدلية': 2, 'أخرى': 3 },
  gender: { 'ذكر': 1, 'أنثى': 2 },
  yearsOfPractice: { '0-5 سنوات': 1, '6-10 سنوات': 2, '11-15 سنة': 3, 'أكثر من 15 سنة': 4 },
  qualification: { 'بكالوريوس صيدلة': 1, 'دكتور صيدلة (PharmD)': 2, 'ماجستير صيدلة سريرية': 3, 'ماجستير علوم صيدلانية': 4, 'دكتوراه': 5, 'أخرى': 6 },
  confidenceLevel: { 'غير واثق': 1, 'واثق قليلاً': 2, 'واثق إلى حد ما': 3, 'واثق جدًا': 4, 'واثق للغاية': 5 },
  receivedTraining: { 'نعم': 1, 'لا': 2, 'أخرى': 3 },
  knowledgeLevel: { 'منخفض': 1, 'متوسط': 2, 'فوق المتوسط': 3, 'عالٍ': 4 },
  likert: { 'أعارض بشدة': 1, 'أعارض': 2, 'محايد': 3, 'أوافق': 4, 'أوافق بشدة': 5, 'لا ينطبق': 6 },
  providesDigitalServices: { 'نعم': 1, 'لا': 2 },
  digitalConsultationPercentage: { '0-20%': 1, '21-40%': 2, '41-60%': 3, '61-80%': 4, '81-100%': 5 },
  pharmacyReadiness: { 'غير جاهز': 1, 'جاهز قليلاً': 2, 'جاهز إلى حد ما': 3, 'جاهز جدًا': 4, 'جاهز بالكامل': 5 }
};

const LOCATION_MAPS = {
  jordan: { 'عمان': 1, 'إربد': 2, 'الزرقاء': 3, 'المفرق': 4, 'جرش': 5, 'عجلون': 6, 'مأدبا': 7, 'البلقاء': 8, 'العقبة': 9, 'الطفيلة': 10, 'الكرك': 11, 'معان': 12 },
  uae: { 'أبوظبي': 1, 'دبي': 2, 'الشارقة': 3, 'رأس الخيمة': 4, 'عجمان': 5, 'أم القيوين': 6, 'الفجيرة': 7 },
  ksa: { 'الرياض': 1, 'مكة المكرمة': 2, 'المدينة المنورة': 3, 'القصيم': 4, 'الشرقية': 5, 'عسير': 6, 'تبوك': 7, 'حائل': 8, 'الحدود الشمالية': 9, 'جازان': 10, 'نجران': 11, 'الباحة': 12, 'الجوف': 13 },
  algeria: { 'أدرار': 1, 'الشلف': 2, 'الأغواط': 3, 'أم البواقي': 4, 'باتنة': 5, 'بجاية': 6, 'بسكرة': 7, 'بشار': 8, 'البليدة': 9, 'البويرة': 10, 'تمنراست': 11, 'تبسة': 12, 'تلمسان': 13, 'تيارت': 14, 'تيزي وزو': 15, 'الجزائر العاصمة': 16, 'الجلفة': 17, 'جيجل': 18, 'سطيف': 19, 'سعيدة': 20, 'سكيكدة': 21, 'سيدي بلعباس': 22, 'عنابة': 23, 'قالمة': 24, 'قسنطينة': 25, 'المدية': 26, 'مستغانم': 27, 'المسيلة': 28, 'معسكر': 29, 'ورقلة': 30, 'وهران': 31, 'البيض': 32, 'إليزي': 33, 'برج بوعريريج': 34, 'بومرداس': 35, 'الطارف': 36, 'تندوف': 37, 'تيسمسيلت': 38, 'الوادي': 39, 'خنشلة': 40, 'سوق أهراس': 41, 'تيبازة': 42, 'ميلة': 43, 'عين الدفلى': 44, 'النعامة': 45, 'عين تموشنت': 46, 'غرداية': 47, 'غليزان': 48, 'تيميمون': 49, 'برج باجي مختار': 50, 'أولاد جلال': 51, 'بني عباس': 52, 'عين صالح': 53, 'عين قزام': 54, 'تقرت': 55, 'جانت': 56, 'المغير': 57, 'المنيعة': 58 }
};

const DIGITAL_TOOLS_MAP = {
  'منصات الاستشارات/المكالمات المرئية': 1, 'تطبيقات الصحة المحمولة': 2, 'السجلات الصحية الإلكترونية': 3,
  'تطبيقات التذكير/المتابعة الدوائية': 4, 'أدوات دعم القرار المدعومة بالذكاء الاصطناعي': 5,
  'منصات الصحة النفسية الرقمية': 6, 'منصات التواصل الاجتماعي': 7, 'أخرى': 8
};

const BARRIERS_MAP = {
  'قيود عبء العمل ونقص الكوادر': 1, 'المهارات والتدريب وسهولة الاستخدام': 2,
  'التكنولوجيا والبنية التحتية والتكامل': 3, 'الحوكمة والخصوصية والمسؤولية القانونية': 4,
  'انخفاض طلب المرضى': 5, 'التمويل والتعويض والعائد على الاستثمار': 6,
  'القيادة والثقافة والدعم المؤسسي': 7, 'وصول المرضى ومحو الأمية الرقمية': 8,
  'الأدلة والنتائج القابلة للقياس': 9, 'أخرى': 10
};

const TRAINING_NEEDS_MAP = {
  'المهارات الرقمية الأساسية': 1, 'التنقل في أدوات الذكاء الاصطناعي': 2,
  'التطبيقات السريرية في صحة المرأة': 3, 'حماية البيانات والخصوصية والموافقة': 4,
  'دمج سير العمل وقابلية التشغيل البيني': 5, 'تثقيف المرضى والمشاركة الرقمية': 6,
  'التعاون بين المهنيين': 7, 'المراقبة والتقييم': 8, 'الدعم العملي': 9, 'أخرى': 10
};

function codeValue(value: string, codingMap: Record<string, number>): number | string {
  return codingMap[value] ?? value;
}

function codeMultipleChoice(values: string[], codingMap: Record<string, number>): string {
  return values.map(v => codingMap[v] ?? v).join(',');
}

export async function appendToGoogleSheet(country: string, data: any) {
  console.log(`[GoogleSheets] appendToGoogleSheet called for ${country}`);
  try {
    const auth = new google.auth.GoogleAuth({
      keyFile: KEYFILE_PATH,
      scopes: ['https://www.googleapis.com/auth/spreadsheets'],
    });

    const sheets = google.sheets({ version: 'v4', auth });
    const sheetId = SHEET_IDS[country.toLowerCase() as keyof typeof SHEET_IDS];

    if (!sheetId) {
      throw new Error(`No sheet ID configured for country: ${country}`);
    }

    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: sheetId,
      range: 'Sheet1!A:A',
    });

    const rowCount = response.data.values?.length || 1;
    const entryNumber = `${country.toUpperCase()}-${String(rowCount).padStart(3, '0')}`;

    const locationMap = LOCATION_MAPS[country.toLowerCase() as keyof typeof LOCATION_MAPS];
    const codedLikertResponses = data.likertResponses.map((r: string) => codeValue(r, CODING_MAPS.likert));

    const rowData = [
      entryNumber,
      new Date().toISOString(),
      country,
      codeValue(data.city, locationMap),
      codeValue(data.environment, CODING_MAPS.environment),
      codeValue(data.pharmacyType, CODING_MAPS.pharmacyType),
      codeValue(data.position, CODING_MAPS.position),
      codeValue(data.gender, CODING_MAPS.gender),
      codeValue(data.yearsOfPractice, CODING_MAPS.yearsOfPractice),
      codeValue(data.qualification, CODING_MAPS.qualification),
      codeValue(data.confidenceLevel, CODING_MAPS.confidenceLevel),
      codeValue(data.receivedTraining, CODING_MAPS.receivedTraining),
      codeValue(data.knowledgeLevel, CODING_MAPS.knowledgeLevel),
      ...codedLikertResponses,
      codeValue(data.providesDigitalServices, CODING_MAPS.providesDigitalServices),
      codeValue(data.digitalConsultationPercentage, CODING_MAPS.digitalConsultationPercentage),
      codeMultipleChoice(data.digitalTools, DIGITAL_TOOLS_MAP),
      codeValue(data.pharmacyReadiness, CODING_MAPS.pharmacyReadiness),
      codeMultipleChoice(data.barriers, BARRIERS_MAP),
      codeMultipleChoice(data.trainingNeeds, TRAINING_NEEDS_MAP),
      data.additionalSupport || '',
      data.digitalCollaborations || '',
      data.ipAddress || ''
    ];

    await sheets.spreadsheets.values.append({
      spreadsheetId: sheetId,
      range: 'Sheet1!A:AK',
      valueInputOption: 'RAW',
      requestBody: { values: [rowData] },
    });

    console.log(`✓ Data appended to ${country} Google Sheet with coded values`);
    return { success: true, entryNumber };
  } catch (error) {
    console.error(`Error appending to Google Sheet for ${country}:`, error);
    throw error;
  }
}

export async function syncResponseToGoogleSheets(responseId: number) {
  try {
    const db = await import('../db').then(m => m.getDb());
    const dbInstance = await db;
    if (!dbInstance) throw new Error('Database not available');
    
    const { responses } = await import('../../drizzle/schema');
    const { eq } = await import('drizzle-orm');
    
    const [response] = await dbInstance.select().from(responses).where(eq(responses.id, responseId));
    if (!response) throw new Error(`Response ${responseId} not found`);
    
    const data = {
      city: response.city,
      environment: response.environment,
      pharmacyType: response.pharmacyType,
      position: response.position,
      gender: response.gender,
      yearsOfPractice: response.yearsOfPractice,
      qualification: response.qualification,
      confidenceLevel: response.confidenceLevel,
      receivedTraining: response.receivedTraining,
      knowledgeLevel: response.knowledgeLevel,
      likertResponses: JSON.parse(response.likertResponses),
      providesDigitalServices: response.providesDigitalServices,
      digitalConsultationPercentage: response.digitalConsultationPercentage,
      digitalTools: JSON.parse(response.digitalTools),
      pharmacyReadiness: response.pharmacyReadiness,
      barriers: JSON.parse(response.barriers),
      trainingNeeds: JSON.parse(response.trainingNeeds),
      additionalSupport: response.additionalSupport,
      digitalCollaborations: response.digitalCollaborations,
      ipAddress: response.ipAddress
    };
    
    await appendToGoogleSheet(response.country, data);
    
    await dbInstance.update(responses)
      .set({ syncedToGoogleSheets: true })
      .where(eq(responses.id, responseId));
    
    console.log(`✓ Response ${responseId} synced to Google Sheets`);
    return { success: true };
  } catch (error) {
    console.error(`Error syncing response ${responseId}:`, error);
    throw error;
  }
}

export async function syncAllUnsyncedResponses() {
  // Placeholder for syncing all unsynced responses
  console.log('Sync all unsynced responses');
  return { success: true, count: 0 };
}

export async function exportToCSV(country?: string) {
  // Placeholder for CSV export
  console.log(`Export to CSV for ${country || 'all countries'}`);
  return { success: true, data: [] };
}
